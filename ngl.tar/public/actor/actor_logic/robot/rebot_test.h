#pragma once

#include "xmlinfo.h"
#include "xmlnode.h"

namespace ngl
{
	class rebot_test
	{
	public:
		static bool is_test;
	};
}