#pragma once

#include "rebot_test.h"

namespace ngl
{
	bool rebot_test::is_test = false;
}