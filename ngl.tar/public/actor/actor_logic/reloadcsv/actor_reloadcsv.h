#pragma once

#include "actor_manage.h"
#include "actor_db_client.h"
#include "actor_protocol.h"
#include "actor_timer.h"
#include "actor_create.h"
#include "db_data.h"
#include "db.h"
#include "db_pool.h"
#include "db_manage.h"
#include "net.h"

namespace ngl
{
	class actor_reloadcsv : public actor
	{
		actor_reloadcsv();
	public:
		friend class actor_instance<actor_reloadcsv>;
		static actor_reloadcsv& getInstance()
		{
			return actor_instance<actor_reloadcsv>::instance();
		}

		virtual void init();
		static void actor_register();

		virtual ~actor_reloadcsv();

		bool handle(message<actor_reloadcsv_pro>& adata);

		// ��ʱ��
		// ��Ӷ�ʱ�� 
		bool timer_handle(message<timerparm>& adata);
	};

	class actor_reloadcsv_distribute
		: public actor
	{
		actor_reloadcsv_distribute();
	public:
		friend class actor_instance<actor_reloadcsv_distribute>;
		static actor_reloadcsv_distribute& getInstance()
		{
			return actor_instance<actor_reloadcsv_distribute>::instance();
		}

		virtual void init();
		static void actor_register();

		virtual ~actor_reloadcsv_distribute();
				
		bool handle(message<actor_reloadcsv_verify_version>& adata);
	};
}