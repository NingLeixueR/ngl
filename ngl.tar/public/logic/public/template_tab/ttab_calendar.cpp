#include "ttab_calendar.h"


namespace ngl
{
	std::map<int32_t, ttab_calendar::data> ttab_calendar::m_data;

}