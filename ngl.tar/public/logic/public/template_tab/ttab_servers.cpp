#include "ttab_servers.h"



namespace ngl
{
	std::map<int16_t, std::vector<tab_servers*>> ttab_servers::m_areaofserver;
}