#include "ttab_attribute.h"


namespace ngl
{
	std::vector<std::pair<int32_t, int32_t>> ttab_attribute::m_uplowlimit;
}