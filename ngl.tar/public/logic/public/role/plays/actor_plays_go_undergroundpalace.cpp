#include "actor_plays_go_undergroundpalace.h"

namespace ngl
{
	actor_plays_go_undergroundpalace::actor_plays_go_undergroundpalace(ENUM_ACTOR atype, int32_t adataid, void* data) :
		actor_plays(atype, adataid, data)
	{

	}

	void actor_plays_go_undergroundpalace::actor_register()
	{
		actor_plays::actor_register();


	}

}