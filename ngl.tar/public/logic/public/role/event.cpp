#include "event.h"
#include "map.h"

namespace ngl
{
	void mapevent::on_death(aoimap* amap, int32_t aunitid)
	{

	}
}