#include "varint.h"
#include <vector>
#include "serialize.h"

namespace ngl
{
    struct varint_impl
    {
        static bool m_isopen;
        static const int32_t m_64maxpos/* = 10*/;
        static const int32_t m_32maxpos/* = 5*/;

        static uint64_t zigzag64encode(int64_t n)
        {
            return (uint64_t)((n >> 63) ^ (n << 1));
        }

        static int64_t zigzag64decode(uint64_t n)
        {
            return (uint64_t)((n >> 1) ^ -(n & 1));
        }

        static uint32_t zigzag32encode(int32_t n)
        {
            return (uint32_t)((n >> 31) ^ (n << 1));
        }

        static int32_t zigzag32decode(uint32_t n)
        {
            return (int32_t)((n >> 1) ^ -(n & 1));
        }
    };

    bool varint_impl::m_isopen;
    const int32_t varint_impl::m_64maxpos = 10;
    const int32_t varint_impl::m_32maxpos = 5;

    void varint::set(bool aisopen)
    {
        varint_impl::m_isopen = aisopen;
    }
    
    int	varint::length(parm_length<int64_t>& avaluearrays)
	{
        if (varint_impl::m_isopen)
        {
            uint64_t ln = varint_impl::zigzag64encode(avaluearrays.m_value);
            if ((ln & (0xffffffffffff << 7)) == 0)
                return 1;
            else if ((ln & (0xffffffffffff << 14)) == 0)
                return 2;
            else if ((ln & (0xffffffffffff << 21)) == 0)
                return 3;
            else if ((ln & (0xffffffffffff << 28)) == 0)
                return 4;
            else if ((ln & (0xffffffffffff << 35)) == 0)
                return 5;
            else if ((ln & (0xffffffffffff << 42)) == 0)
                return 6;
            else if ((ln & (0xffffffffffff << 49)) == 0)
                return 7;
            else if ((ln & (0xffffffffffff << 56)) == 0)
                return 8;
            else if ((ln & (0xffffffffffff << 63)) == 0)
                return 9;
            else
                return 10;
        }
        else
            return sizeof(int64_t);
	}

    int varint::length(parm_length<int32_t>& avaluearrays)
    {
        if (varint_impl::m_isopen)
        {
            uint64_t ln = varint_impl::zigzag64encode(avaluearrays.m_value);
            if ((ln & (0xffffffffffff << 7)) == 0)
                return 1;
            else if ((ln & (0xffffffffffff << 14)) == 0)
                return 2;
            else if ((ln & (0xffffffffffff << 21)) == 0)
                return 3;
            else if ((ln & (0xffffffffffff << 28)) == 0)
                return 4;
            else
                return 5;
        }
        else
            return sizeof(int32_t);
    }

    template <typename T>
    bool encodebasetype(char* buf, int len, const T* adata, int32_t adatalen, int32_t* bytes)
    {
        if (sizeof(T) > len)
            return false;
        memcpy(buf, adata, sizeof(T)* adatalen);
        *bytes += sizeof(T) * adatalen;
        return true;
    }

    bool varint::encode(parm<int64_t>& aparm)
    {
        if (varint_impl::m_isopen == false)
        {
            if (encodebasetype(aparm.m_buf, aparm.m_len, &aparm.m_value, 1, aparm.m_bytes) == false)
                return false;
            return true;
        }
        else
        {
            uint64_t ln = varint_impl::zigzag64encode(aparm.m_value);
            int32_t index = 0;
            while (true)
            {
                if (index > aparm.m_len || index > varint_impl::m_64maxpos)
                    return false;
                //0x7F ����0111 1111
                //~ ��ʾȡ��  
                if ((ln & ~0x7F) == 0)
                {
                    aparm.m_buf[index] = (uint8_t)(ln & 0x7F);
                    break;
                }
                else
                {
                    //ȡ��7λ���ڵ�8λ���ϱ��1
                    aparm.m_buf[index] = (uint8_t)((ln & 0x7F) | 0x80);
                    index++;
                    //�Ѿ���������ȥ
                    ln = ln >> 7;
                }
            }
            *aparm.m_bytes += index + 1;
            return true;
        }
    }

    bool varint::encode(parm<int32_t>& aparm)
    {
        if (varint_impl::m_isopen == false)
        {
            if (encodebasetype(aparm.m_buf, aparm.m_len, &aparm.m_value, 1, aparm.m_bytes) == false)
                return false;
            return true;
        }
        else
        {
            uint32_t ln = varint_impl::zigzag32encode(aparm.m_value);
            int index = 0;
            while (true)
            {
                if (index > aparm.m_len || index > varint_impl::m_32maxpos)
                    return false;
                //0x7F ����0111 1111
                //~ ��ʾȡ��  
                if ((ln & ~0x7F) == 0)
                {
                    aparm.m_buf[index] = (uint8_t)(ln & 0x7F);
                    break;
                }
                else
                {
                    //ȡ��7λ���ڵ�8λ���ϱ��1
                    aparm.m_buf[index] = (uint8_t)((ln & 0x7F) | 0x80);
                    index++;
                    //�Ѿ���������ȥ
                    ln = ln >> 7;
                }
            }
            *aparm.m_bytes += index + 1;
            return true;
        }
    }

    template <typename T>
    bool decodebasetype(const char* buf, int len, int32_t* bytes, T* adata, int32_t adatalen)
    {
        int llen = sizeof(T) * adatalen;
        if (llen > len)
            return false;
        memcpy(adata, buf, llen);
        *bytes += llen;
        return true;
    }

    bool varint::decode(parm<int64_t>& aparm)
    {
        if (varint_impl::m_isopen == false)
        {
            if (decodebasetype(aparm.m_buf, aparm.m_len, aparm.m_bytes, &aparm.m_value, 1) == false)
                return false;
            return true;
        }
        else
        {
            aparm.m_value = 0;
            int i = 0;
            for (; i < aparm.m_len; i++)
            {
                uint8_t b = aparm.m_buf[i];
                //0x7F ����0111 1111
                //ȡ��7λȻ�����ƣ���Ϊ��С�˴洢
                uint8_t c = (b & 0x7F);
                aparm.m_value |= (int64_t)c << (i * 7);
                // 0x80 �� 1000 0000
                //��8λ��0 ˵������û���ֽ���
                if ((uint8_t)(b & 0x80) == 0)
                {
                    break;
                }
                if (i > varint_impl::m_64maxpos)
                    break;
            }
            *aparm.m_bytes += i + 1;
            aparm.m_value = varint_impl::zigzag64decode(aparm.m_value);
            return true;
        }
    }

    bool varint::decode(parm<int32_t>& aparm)
    {
        if (varint_impl::m_isopen == false)
        {
            int32_t lbytes = 0;
            if (decodebasetype(aparm.m_buf, aparm.m_len, &lbytes, &aparm.m_value, 1) == false)
                return false;
            *aparm.m_bytes += lbytes;
            return true;
        }
        else
        {
            aparm.m_value = 0;
            int i = 0;
            for (; i < aparm.m_len; i++)
            {
                uint8_t b = aparm.m_buf[i];
                //0x7F ����0111 1111
                //ȡ��7λȻ�����ƣ���Ϊ��С�˴洢
                aparm.m_value |= (b & 0x7F) << (i * 7);
                // 0x80 �� 1000 0000
                //��8λ��0 ˵������û���ֽ���
                if ((uint8_t)(b & 0x80) == 0)
                {
                    break;
                }
                if (i > varint_impl::m_32maxpos)
                    break;
            }
            *aparm.m_bytes += i + 1;
            aparm.m_value = varint_impl::zigzag32decode(aparm.m_value);
            return true;
        }
    }
    
    void test_varint()
    {
       /* std::vector<int32_t> lvec;
        for (int i = 0; i < 10000; ++i)
            lvec.push_back(rand());
        {
            ngl::varint::set(true);
            char lbuff[402400] = { 0 };
            ngl::serialize lserialize(lbuff, 402400);

            lserialize.push((int)lvec.size());
            for (int i = 0; i < lvec.size(); ++i)
                lserialize.push(lvec[i]);
            std::cout << "varint open:" << lserialize.byte() << std::endl;
            std::vector<int32_t> lvec2;
            ngl::unserialize lunserialize(lbuff, 402400);
            int lsize = 0;
            lunserialize.pop(lsize);
            lvec2.resize(lsize);

            for (int i = 0; i < lvec2.size(); ++i)
                lunserialize.pop(lvec2[i]);
        }
        {
            ngl::varint::set(false);
            char lbuff[402400] = { 0 };
            ngl::serialize lserialize(lbuff, 402400);
            lserialize.push((int)lvec.size());
            for (int i = 0; i < lvec.size(); ++i)
                lserialize.push(lvec[i]);
            std::cout << "varint not open:" << lserialize.byte() << std::endl;
            std::vector<int64_t> lvec2;
            ngl::unserialize lunserialize(lbuff, 402400);
            int lsize = 0;
            lunserialize.pop(lsize);
            lvec2.resize(lsize);

            for (int i = 0; i < lvec2.size(); ++i)
                lunserialize.pop(lvec2[i]);
        }*/
    }
}