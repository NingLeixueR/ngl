#pragma once

#include <functional>
#include <map>
#include "threadtools.h"
#include "nlog.h"
#include "type.h"
#include "actor_enum.h"
#include "pack.h"
#include "actor_protocol.h"
#include "handle_pram.h"
#include "structbytes.h"
#include "actor_guid.h"
#include "actor_manage.h"
#include "init_protobuf.h"

namespace ngl
{
	class protocol
	{
	public:
		using typefun_pack = std::function<std::shared_ptr<void>(std::shared_ptr<pack>&)>;
		using typefun_run = std::function<bool(std::shared_ptr<pack>&, std::shared_ptr<void>&)>;
	public:
		static void push(std::shared_ptr<pack>& apack);
		static void register_protocol(
			EPROTOCOL_TYPE atype					// Э������
			, i32_protocolnum aprotocolnumber		// Э���
			, ENUM_ACTOR aenumactor					// actor����
			, const typefun_pack& apackfun			// ����ص�
			, const typefun_run& arunfun			// �߼��ص�
			, const char* aname);
		static i32_serverid nodeid();

		//// --- ACTOR��ͨ�� 
		template <typename T, EPROTOCOL_TYPE TYPE>
		static void registry_actor(ENUM_ACTOR atype, const char* aname)
		{
			typefun_pack lpackfun = [](std::shared_ptr<pack>& apack)->std::shared_ptr<void>
			{
				Try
				{
					T* lp = new T();
					std::shared_ptr<void> ltemp(lp);
					//std::cout << typeid(T).name() << std::endl;
					if (structbytes<T>::tostruct(apack, *lp))
					{
						return ltemp;
					}
				}Catch;
				return nullptr;
			};
			typefun_run lrunfun = [atype](std::shared_ptr<pack>& apack, std::shared_ptr<void>& aptrpram)->bool
			{
				actor_guid lactorguid(apack->m_head.get_actor());
				actor_guid lrequestactorguid(apack->m_head.get_request_actor());
				std::shared_ptr<T> ldatapack = std::static_pointer_cast<T>(aptrpram);
				handle_pram lpram;
				handle_pram::create<T, false, false>(lpram
					, lactorguid
					, lrequestactorguid
					, ldatapack
				);
				lpram.m_pack = apack;

				if (lactorguid.is_actortypenone() || lactorguid.is_moreactor(atype))
				{// actor type �Ƿ���Ч  || //����ͬ���͵�����actor
					actor_manage::getInstance().push_task_type(atype, lpram);
					return true;
				}
				else
				{
					if (lactorguid.type() == atype)
					{
						if (lactorguid.is_actoridnone())// actor id �Ƿ���Ч
							actor_manage::getInstance().push_task_type(atype, lpram);
						else
							actor_manage::getInstance().push_task_id(lactorguid.id(), lpram, false);
					}
				}
				return true;
			};
			register_protocol(TYPE, init_protobuf::protocol<T>(), atype, lpackfun, lrunfun, aname);
		}

		// ת��[����ת����actor�����ǵ���actor]
		template <typename T, bool ISTRUE, EPROTOCOL_TYPE TYPE>
		static void registry_actor_forward(ENUM_ACTOR atype, int32_t aprotocolnum, const char* aname)
		{
			typefun_pack lpackfun = [](std::shared_ptr<pack>& apack)->std::shared_ptr<void>
			{
					Try
					{
						using typeforward = actor_forward<T, TYPE, ISTRUE, ngl::forward>;
						typeforward* lp = new typeforward();
						lp->m_recvpack = apack;
						std::shared_ptr<void> ltemp(lp);
						if (structbytes<typeforward>::tostruct(apack, *lp, true) == false)
							return nullptr;
						return ltemp;
				}Catch;
				return nullptr;
			};
			typefun_run lrunfun = [atype](std::shared_ptr<pack>& apack, std::shared_ptr<void>& aptrpram)->bool
			{
				using typeforward = actor_forward<T, TYPE, ISTRUE, ngl::forward>;
				std::shared_ptr<typeforward> ldatapack = std::static_pointer_cast<typeforward>(aptrpram);
				actor_guid lguid(atype, tab_self_area, nconfig::m_nodeid);
				actor_guid lrequestguid(apack->m_head.get_request_actor());
				handle_pram lpram;
				handle_pram::create(lpram, lguid, lrequestguid, ldatapack);
				lpram.m_pack = apack;
				actor_manage::getInstance().push_task_id(lguid, lpram, false);
				return true;
			};			
			register_protocol(TYPE, aprotocolnum, atype, lpackfun, lrunfun, aname);
		}

		// ����ת������Ϣ
		template <typename T, bool ISTRUE, EPROTOCOL_TYPE TYPE>
		static void registry_actor_recvforward(ENUM_ACTOR atype, int32_t aprotocolnum, const char* aname)
		{
			typefun_pack lpackfun = [](std::shared_ptr<pack>& apack)->std::shared_ptr<void>
			{
					Try
					{
						using typeforward = actor_forward<T, TYPE, ISTRUE, T>;
						typeforward* lp = new typeforward();
						std::shared_ptr<void> ltemp(lp);
						if (structbytes<typeforward>::tostruct(apack, *lp) == false)
							return nullptr;
						return ltemp;
				}Catch;
				return nullptr;
			};
			typefun_run lrunfun = [atype](std::shared_ptr<pack>& apack, std::shared_ptr<void>& aptrpram)->bool
			{
				using typeforward = actor_forward<T, TYPE, ISTRUE, T>;
				actor_guid lrequestguid(apack->m_head.get_request_actor());
				std::shared_ptr<T> ldatapack = std::static_pointer_cast<T>(aptrpram);
				typeforward* lp = (typeforward*)aptrpram.get();
				for (int i = 0; i < lp->m_uid.size() && i < lp->m_area.size(); ++i)
				{
					actor_guid lguid(atype, lp->m_area[i], lp->m_uid[i]);
					handle_pram lpram;
					handle_pram::create<T, false, false>(lpram, lguid, lrequestguid, ldatapack);
					actor_manage::getInstance().push_task_id(lguid, lpram, false);
				}
				return true;
			};
			register_protocol(TYPE, aprotocolnum, atype, lpackfun, lrunfun, aname);			
		}
	};
}