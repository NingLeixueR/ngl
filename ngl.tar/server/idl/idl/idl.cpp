#include "idl.h"

std::set<std::string> Struct::m_basetype;
